# Soter
Detecting and Blocking malicious URL using Machine Learning


Download extention: https://github.com/CTA-G-14/Soter.
![step1](https://user-images.githubusercontent.com/61678470/117578627-dff48500-b10c-11eb-9645-79d31e1c2741.png)


Click on Code button and select download ZIP.
![Step2](https://user-images.githubusercontent.com/61678470/117578628-e1be4880-b10c-11eb-86eb-9f3f6345d91e.png)


Extract the code after successfully  download.
![step3](https://user-images.githubusercontent.com/61678470/117578630-e2ef7580-b10c-11eb-9a86-af7448f4b7c3.png)


Go to chrome settings :  chrome://settings/content/javascript?search=java
 and allow Javascript.
![Step4](https://user-images.githubusercontent.com/61678470/117578635-e551cf80-b10c-11eb-861c-3089a834ec75.png)


Go to extenstion setting:  chrome://extensions/
and allow Developers mode.
![Step5](https://user-images.githubusercontent.com/61678470/117578636-e5ea6600-b10c-11eb-8450-307240acbfb8.png)


Then select Load unpacked.
![Step6](https://user-images.githubusercontent.com/61678470/117578637-e682fc80-b10c-11eb-812d-0b0d81cc9a30.png)


Select the extracted folder.
![Step7](https://user-images.githubusercontent.com/61678470/117578639-e71b9300-b10c-11eb-9867-66bfc5f392c6.png)


Extension will appear.
![Step8](https://user-images.githubusercontent.com/61678470/117578640-e7b42980-b10c-11eb-8bfd-bbb0e86690cf.png)


General details about extension.
![step9](https://user-images.githubusercontent.com/61678470/117578643-e84cc000-b10c-11eb-931a-8591a9bb03f7.png)


Click on extension icon infront of  URL bar.
![step10](https://user-images.githubusercontent.com/61678470/117578644-e8e55680-b10c-11eb-8f85-b71dc73cf6a3.png)


Pin the extension.
![step11](https://user-images.githubusercontent.com/61678470/117578645-e97ded00-b10c-11eb-8e49-7348e9166849.png)


Search any website
Website is SAFE will notify for safe websites.
![step12](https://user-images.githubusercontent.com/61678470/117578646-ea168380-b10c-11eb-937d-ce2d07841dce.png)


Warning will notify for malicious websites.
![step13](https://user-images.githubusercontent.com/61678470/117578651-f0a4fb00-b10c-11eb-8614-1d04703c01c0.png)


If you want to block click on extension icon.
![step14](https://user-images.githubusercontent.com/61678470/117578655-f26ebe80-b10c-11eb-80fc-9befa4d61971.png)


Choice will appear
![step15](https://user-images.githubusercontent.com/61678470/117578657-f4d11880-b10c-11eb-8cec-eb4a3fe640f9.png)


After blocking the site extension turns red in color.
![step16](https://user-images.githubusercontent.com/61678470/117578658-f7337280-b10c-11eb-8b1e-82b3b03525ed.png)


To unblock the site click on unblock option and refresh page.
![step17](https://user-images.githubusercontent.com/61678470/117578659-f8649f80-b10c-11eb-8527-f6c84d115f4f.png)


Site will be unblock.
![step18](https://user-images.githubusercontent.com/61678470/117578660-f995cc80-b10c-11eb-8116-4a926afab00d.png)
